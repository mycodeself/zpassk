<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures;

use Symfony\Component\DependencyInjection\Definition;

class TestDefinition2 extends Definition
{
}
