<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\includes\HotPath;

class C1 extends P1
{
    use T1;
}
