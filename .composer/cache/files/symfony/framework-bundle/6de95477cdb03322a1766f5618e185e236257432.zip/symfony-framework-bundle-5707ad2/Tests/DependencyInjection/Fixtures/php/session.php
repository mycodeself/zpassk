<?php

$container->loadFromExtension('framework', [
    'session' => [
        'handler_id' => null,
    ],
]);
