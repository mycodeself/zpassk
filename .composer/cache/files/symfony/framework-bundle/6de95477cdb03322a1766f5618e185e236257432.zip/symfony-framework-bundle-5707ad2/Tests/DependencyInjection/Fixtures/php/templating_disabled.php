<?php

$container->loadFromExtension('framework', [
    'templating' => false,
]);
