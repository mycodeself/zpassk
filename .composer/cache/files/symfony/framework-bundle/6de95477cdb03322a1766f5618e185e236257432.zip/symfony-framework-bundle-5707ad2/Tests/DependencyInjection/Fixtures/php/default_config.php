<?php

$container->loadFromExtension('framework', []);
