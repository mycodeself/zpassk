<?php

$container->loadFromExtension('framework', [
    'web_link' => ['enabled' => true],
]);
