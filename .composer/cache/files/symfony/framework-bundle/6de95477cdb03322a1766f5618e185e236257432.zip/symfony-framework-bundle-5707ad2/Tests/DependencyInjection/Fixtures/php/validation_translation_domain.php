<?php

$container->loadFromExtension('framework', [
    'validation' => [
        'translation_domain' => 'messages',
    ],
]);
