<?php

$container->loadFromExtension('framework', [
    'ssi' => [
        'enabled' => false,
    ],
]);
