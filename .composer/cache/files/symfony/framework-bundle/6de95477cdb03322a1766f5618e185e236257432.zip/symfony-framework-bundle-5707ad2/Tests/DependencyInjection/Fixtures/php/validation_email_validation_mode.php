<?php

$container->loadFromExtension('framework', [
    'validation' => [
        'email_validation_mode' => 'html5',
    ],
]);
