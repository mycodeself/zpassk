<?php

$container->loadFromExtension('framework', [
    'csrf_protection' => [
        'enabled' => true,
    ],
]);
