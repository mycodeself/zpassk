<?php

$container->loadFromExtension('framework', [
    'templating' => [
        'engines' => ['php', 'twig'],
    ],
]);
