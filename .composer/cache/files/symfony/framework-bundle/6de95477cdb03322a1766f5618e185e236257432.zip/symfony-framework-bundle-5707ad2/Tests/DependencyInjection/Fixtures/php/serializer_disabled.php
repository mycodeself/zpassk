<?php

$container->loadFromExtension('framework', [
    'serializer' => [
        'enabled' => false,
    ],
]);
