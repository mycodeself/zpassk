<?php

$container->loadFromExtension('framework', [
    'request' => [
        'formats' => [],
    ],
]);
