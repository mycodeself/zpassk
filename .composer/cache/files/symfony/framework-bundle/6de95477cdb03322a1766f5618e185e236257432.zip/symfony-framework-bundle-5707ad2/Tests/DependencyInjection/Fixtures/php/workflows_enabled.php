<?php

$container->loadFromExtension('framework', [
    'workflows' => null,
]);
