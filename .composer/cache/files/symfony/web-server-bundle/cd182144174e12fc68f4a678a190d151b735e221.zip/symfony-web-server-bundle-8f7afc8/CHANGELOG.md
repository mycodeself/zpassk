CHANGELOG
=========

4.2.0
-----

 * Added ability to display the current hostname address if available when binding to 0.0.0.0

3.4.0
-----

 * WebServer can now use '*' as a wildcard to bind to 0.0.0.0 (INADDR_ANY)

3.3.0
-----

 * Added bundle
