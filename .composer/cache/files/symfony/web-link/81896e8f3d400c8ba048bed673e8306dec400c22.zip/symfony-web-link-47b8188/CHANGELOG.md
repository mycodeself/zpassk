CHANGELOG
=========

3.3.0
-----

 * added the component
