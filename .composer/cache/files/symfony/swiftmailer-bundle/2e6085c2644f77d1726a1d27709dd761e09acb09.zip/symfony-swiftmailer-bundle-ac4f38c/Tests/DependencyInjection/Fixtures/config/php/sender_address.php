<?php

$container->loadFromExtension('swiftmailer', [
    'sender_address' => 'noreply@test.com',
]);
