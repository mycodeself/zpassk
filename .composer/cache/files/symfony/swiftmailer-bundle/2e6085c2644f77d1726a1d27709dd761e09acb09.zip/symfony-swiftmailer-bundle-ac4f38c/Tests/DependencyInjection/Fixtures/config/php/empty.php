<?php

$container->loadFromExtension('swiftmailer', []);
