# Chromedriver Binaries

Chromedriver: https://sites.google.com/a/chromium.org/chromedriver/downloads
See [notes.txt](notes.txt).
