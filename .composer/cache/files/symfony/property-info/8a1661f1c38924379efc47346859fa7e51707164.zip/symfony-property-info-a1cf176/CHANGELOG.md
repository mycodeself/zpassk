CHANGELOG
=========

4.2.0
-----

* added `PropertyInitializableExtractorInterface` to test if a property can be initialized through the constructor (implemented by `ReflectionExtractor`)

3.3.0
-----

* Added `PropertyInfoPass`
