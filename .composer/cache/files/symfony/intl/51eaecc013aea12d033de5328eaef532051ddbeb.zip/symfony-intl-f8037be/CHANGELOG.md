CHANGELOG
=========

4.2.0
-----

 * excluded language codes `mis`, `mul`, `und` and `zxx`
