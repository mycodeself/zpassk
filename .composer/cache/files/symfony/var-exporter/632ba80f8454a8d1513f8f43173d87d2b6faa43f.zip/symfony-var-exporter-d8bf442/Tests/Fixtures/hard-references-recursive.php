<?php

return \Symfony\Component\VarExporter\Internal\Hydrator::hydrate(
    $o = [],
    [
        $r = [],
        $r[1] = [
            &$r[1],
        ],
    ],
    [],
    [
        &$r[1],
    ],
    []
);
