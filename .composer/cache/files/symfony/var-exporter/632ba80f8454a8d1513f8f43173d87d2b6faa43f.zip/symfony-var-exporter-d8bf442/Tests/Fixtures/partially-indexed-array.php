<?php

return [
    5 => true,
    1 => true,
    2 => true,
    true,
];
