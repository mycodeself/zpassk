<?php

require_once __DIR__.'/composer/autoload_real.php';
