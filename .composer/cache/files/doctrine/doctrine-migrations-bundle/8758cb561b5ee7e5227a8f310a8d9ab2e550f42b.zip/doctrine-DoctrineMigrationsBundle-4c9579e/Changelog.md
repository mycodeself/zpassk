## 1.1.0 (2015-09-29)

Features:

* Allowed DoctrineMigrationsBundle to work with Symfony apps using DBAL only

## 1.0.1 (2015-05-06)

* Allowed Symfony 3.0 components

## 1.0.0 (2014-08-17)

Initial stable release
