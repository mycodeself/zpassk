<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Finder\Exception;

interface FinderException
{
}
