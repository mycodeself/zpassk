<?php

namespace Twig;

class_exists('Twig_FileExtensionEscapingStrategy');

if (\false) {
    class FileExtensionEscapingStrategy extends \Twig_FileExtensionEscapingStrategy
    {
    }
}
