<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_Sub');

if (\false) {
    class SubBinary extends \Twig_Node_Expression_Binary_Sub
    {
    }
}
