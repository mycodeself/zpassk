<?php

namespace Twig\Node\Expression\Test;

class_exists('Twig_Node_Expression_Test_Null');

if (\false) {
    class NullTest extends \Twig_Node_Expression_Test_Null
    {
    }
}
