<?php

namespace Twig\Sandbox;

class_exists('Twig_Sandbox_SecurityPolicyInterface');

if (\false) {
    interface SecurityPolicyInterface extends \Twig_Sandbox_SecurityPolicyInterface
    {
    }
}
