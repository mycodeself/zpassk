<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParserInterface');

if (\false) {
    interface TokenParserInterface extends \Twig_TokenParserInterface
    {
    }
}
