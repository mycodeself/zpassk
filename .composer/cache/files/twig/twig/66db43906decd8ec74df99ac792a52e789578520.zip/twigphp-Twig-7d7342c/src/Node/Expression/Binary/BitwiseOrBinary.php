<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_BitwiseOr');

if (\false) {
    class BitwiseOrBinary extends \Twig_Node_Expression_Binary_BitwiseOr
    {
    }
}
