<?php

namespace Twig\Profiler\Node;

class_exists('Twig_Profiler_Node_EnterProfile');

if (\false) {
    class EnterProfileNode extends \Twig_Profiler_Node_EnterProfile
    {
    }
}
