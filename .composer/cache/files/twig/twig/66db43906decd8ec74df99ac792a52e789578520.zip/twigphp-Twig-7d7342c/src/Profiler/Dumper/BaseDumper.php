<?php

namespace Twig\Profiler\Dumper;

class_exists('Twig_Profiler_Dumper_Base');

if (\false) {
    class BaseDumper extends \Twig_Profiler_Dumper_Base
    {
    }
}
